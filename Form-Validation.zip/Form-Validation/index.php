<!DOCTYPE html>
<html>
<head>
    <title>Contact Us</title>
</head>
<body>
    <h1>Contact Us</h1>
    <form method="post" action="process_form.php">
        <label for="full_name">Full Name:</label><br>
        <input type="text" id="full_name" name="full_name" size="30"><br>
        
        <label for="phone_number">Phone Number:</label><br>
        <input type="text" id="phone_number" name="phone_number" size="30"><br>
        
        <label for="email">Email:</label><br>
        <input type="text" id="email" name="email" size="30"><br>
        
        <label for="subject">Subject:</label><br>
        <input type="text" id="subject" name="subject" size="30"><br>
        
        <label for="message">Message:</label><br>
        <textarea id="message" name="message" rows="5" cols="30"></textarea><br>
        
        <input type="submit" value="Submit">
    </form>
</body>
</html>

<?php
// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "form";

// Establish database   connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = $_POST["full_name"];
    $phone_number = $_POST["phone_number"];
    $email = $_POST["email"];
    $subject = $_POST["subject"];
    $message = $_POST["message"];
    $ip_address = $_SERVER["REMOTE_ADDR"];
    $timestamp = date("Y-m-d H:i:s");

    // Validate form fields
    if (empty($full_name) || empty($phone_number) || empty($email) || empty($subject) || empty($message)) {
        echo "All fields are mandatory. Please fill in all fields.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Invalid email format.";
    } else {
        // Insert data into the database
        $sql = "INSERT INTO contact_form (full_name, phone_number, email, subject, message, ip_address, timestamp)
                VALUES ('$full_name', '$phone_number', '$email', '$subject', '$message', '$ip_address', '$timestamp')";

        if ($conn->query($sql) === TRUE) {
            echo "Form submitted successfully!";
            // Send email notification to site owner
            $to = "prem756383@gmail.com";
            $subject = "New Form Submission";
            $message = "A new form submission has been received.\n\n"
                . "Full Name: $full_name\n"
                . "Phone Number: $phone_number\n"
                . "Email: $email\n"
                . "Subject: $subject\n"
                . "Message: $message\n"
                . "IP Address: $ip_address\n"
                . "Timestamp: $timestamp";
            mail($to, $subject, $message);
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}

$conn->close();
?>

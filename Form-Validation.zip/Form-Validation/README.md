# Form

install xampp server and start apache and mysql
create database in phpmyadmin database name from
import contact_form.sql
